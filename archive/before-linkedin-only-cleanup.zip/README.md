# Orbit — AI job application workspace

A local first implementation of the agreed product. **There is no login page.** The app opens personal onboarding immediately. Dashboard access follows profile completion and confirmation. Discover jobs has been removed from the interface.

## Run locally

Requires Node 22+ and Python 3.11+.

```powershell
npm install
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r backend/requirements.txt
Copy-Item .env.example .env  # Only on a fresh setup; do not overwrite existing keys.
.\start.ps1
```

Open http://127.0.0.1:3000. The current workspace already has its dependencies installed and private local configuration prepared. `start.ps1` starts FastAPI in a hidden child process and Next.js in the current terminal. Stop with Ctrl+C. API documentation is at http://127.0.0.1:8000/docs. Browser mutations use the configured Origin header.

## Implemented

- Next.js/React interface: overview, job discovery, application tracker, live agent, five-step onboarding, preferences.
- Analytics calculated from database records with 7/30/90-day filters, discovery/application activity and conversion funnel. Sources are deduplicated by canonical application URL per user.
- Persistent local workspaces backed by HttpOnly session cookies. The backend also has register/login endpoints for later UI integration.
- Resume text extraction from PDF, DOCX and TXT (5 MB limit), profile confirmation, country/location/work mode preferences, skills, experience, salary, authorization, sponsorship and screening answers.
- Greenhouse and Ashby public board discovery by company board slug; extracted listings retain original application links.
- Deterministic prefiltering with unresolved eligibility explicitly represented. Live AI assessment uses only the pinned DeepSeek model. Match is an estimate, not an employer ATS score.
- Job-specific resume and cover-letter generation, document editing, DOCX download and approval hashes. Changes invalidate previous approval.
- Individual approval, batch approval and explicitly enabled automatic mode, with daily reservations and a single-process pilot dispatcher for already-discovered eligible jobs.
- Browserbase session creation, Live View retrieval, embedded human takeover, pause/resume/stop and a constrained Python Playwright action loop. Only supported Greenhouse/Ashby application hosts are allowed in the initial adapter.
- Confirmed submission evidence is required for “Applied.” An ambiguous submission enters `needs_verification` and cannot be automatically retried.
- SSE refresh notifications and persisted activity events. Demo runs simulate the stages and never visit or submit employer forms.
- Single-process restart recovery marks interrupted runs for review.

## Connections

Set secrets only in `.env` or the deployment secret store. Never use `NEXT_PUBLIC_` for API keys.

```dotenv
OPENROUTER_API_KEY=
BROWSERBASE_API_KEY=
```

The Browserbase key supplied with the onboarding attachment is configured locally in the ignored `.env`; it is not in source. Browserbase resolves the project from the key. Human takeover relies on a session with `keepAlive` support. Browserbase handles supported challenges; unresolved CAPTCHA, login, verification and consent require the user.

Every AI call is pinned to **`deepseek/deepseek-v4-flash-0731`**. There is no alternate-model fallback and no Browserbase Model Gateway use. Without the OpenRouter key, live AI matching, tailoring and automated applications return a clear unavailable response. Public board discovery and profile editing still work in the personal workspace.

## Database

This running development preview uses SQLite so no external database installation is needed. The SQLAlchemy schema also targets PostgreSQL. To use PostgreSQL:

1. Set `POSTGRES_PASSWORD` to a strong local secret.
2. Run `docker compose up -d postgres`.
3. Set `DATABASE_URL=postgresql+psycopg://orbit:<URL-encoded-password>@127.0.0.1:5432/orbit` in `.env`.
4. Restart the backend. Tables are created on first start. Existing SQLite data is not migrated automatically.

## Verification

```powershell
npm run build
.\.venv\Scripts\python.exe -m unittest backend.test_api -v
```

Tests use an isolated temporary database and no external model/browser calls. They cover ownership boundaries, invalid origins, upload/download, exact-package approval, demo lifecycle, daily limits, uncertain eligibility and non-retryable ambiguous submissions.

Verified during this build: production compilation and type checking; all 13 integration tests; direct workspace entry, document review and demo approval in the browser; desktop and narrow layouts; Browserbase session creation with keep-alive and a Live View URL (then released); Ashby discovery returned 32 public Linear listings. The OpenRouter integration remains untested without its key.

## Current boundaries before production

- The live DeepSeek/browser application loop is implemented but cannot be validated end to end until the OpenRouter key is supplied. No real employer applications were submitted during development.
- Workday, Indeed, LinkedIn, Glassdoor, ZipRecruiter and Google Jobs are explicitly marked **not connected yet**. Broader web discovery, company-board discovery, scheduled source refresh and each additional portal need adapters and tests. Current discovery requires a known Greenhouse/Ashby company board slug.
- The first automatic dispatcher processes already-assessed jobs. It is a **single-process pilot**, not a Redis/Celery production worker. Run one backend process. Move execution to durable workers with database leases before deploying multiple processes.
- PostgreSQL is configured but not exercised in this local SQLite preview. Add migration management and PostgreSQL integration tests before launch.
- Local cookie identities are for development; clearing browser cookies loses access until identities are linked to real accounts. Before production: restore user authentication/account recovery, add rate limits, cleanup/retention and deletion/export, encrypted browser context storage, private object storage, secret rotation, deployment monitoring and upload hardening.
- No cross-session login persistence is implemented beyond the active Browserbase session. Expired sessions require human login again. Browser adapters conservatively stop on unsupported inputs, ambiguous answers or missing requirements.
- No inbox integration: interview, rejection and offer outcomes are not fabricated. No billing integration, publication or deployment has been performed.
- The current UI is implemented directly in Next.js. A separate Figma design file has not been created.

## Structure

`app/` — interface and design tokens. `backend/main.py` — API and pilot dispatcher. `backend/domain.py` — matching rules and demo fixtures. `backend/services.py` — external connectors and pinned AI gateway. `backend/worker.py` — controlled browser execution. `backend/db.py` — persistence. `backend/test_api.py` — isolated integration checks.


Updated flow: basic details and resume upload, education and work history, desired role and preferences, eligibility and answers, final profile review, then dashboard. Resume suggestions are extracted locally without an LLM; unrecognized values remain blank and existing details are preserved. Optional demographics are never inferred. The agent screen retains Start/Pause/Stop controls; these are disabled with a connection message when there is no connected application workflow.


## Batched form execution

The browser worker snapshots the whole visible form and asks DeepSeek for one validated action batch, including document uploads and the final navigation/submission action. It executes that batch without per-field LLM calls and re-inspects only for a changed page or further form work. Invalid mappings reject the batch before mutations. Existing pause checks, package approval validation and confirmation checks remain in force. Synthetic browser verification passed with one model batch in 49.64 seconds versus approximately 126 seconds in the earlier per-action run; filling/uploading took approximately seven seconds. Model latency varies. Run `python -m backend.live_smoke --form-only` for a browser-only timing check using fictional documents.
