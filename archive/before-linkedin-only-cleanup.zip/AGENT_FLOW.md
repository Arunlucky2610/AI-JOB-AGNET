# Autonomous agent flow

The Live agent page starts discovery from the confirmed profile. There is no company-board selector. Searches target employer-owned career sites and branded ATS vacancies, including Workday, Ashby, Greenhouse, Lever and SmartRecruiters. LinkedIn, Indeed and other known job aggregators are excluded from candidate and application destinations. The model must additionally verify employer-portal provenance before saving an eligible vacancy.

Discovery uses Exa MCP and public-page reading uses Jina Reader, following the backend approach described in [Agent Reach](https://github.com/Panniantong/Agent-Reach). The Agent Reach installer and desktop cookie import are not used. The app activity log shows discovery queries and source results; Browserbase shows inspected portals and application actions in Live View. Public search services can fail or impose quotas; a browser search fallback is available, and verification requires human input.

The pinned DeepSeek model extracts individual vacancies, checks mandatory profile constraints, estimates resume/JD fit, and prepares tailored resume and cover-letter drafts for qualifying jobs. Fit scores are estimates, not an employer's ATS result. Listing pages and closed vacancies are skipped. Missing mandatory eligibility evidence prevents automatic matching.

Exact package approval, batch approval, or explicitly enabled automatic rules govern submission. Approved packages dispatch to the existing browser worker. Missing answers, login, consent and verification require human takeover. Only employer confirmation counts as submitted.

Agent runs persist search/candidate checkpoints and activity. Pause and resume retain the same run. Stop releases discovery and interrupts active forms before submission. Restarts pause runs. A disconnected browser is renewed before the next page; a session ending during inspection preserves that page for resume rather than counting the remaining pages as processed. This remains a single-process pilot; public discovery does not establish that every authenticated portal application flow has been tested.

Salary does not affect job eligibility, matching or fit scoring. The saved expectation remains available for truthful screening answers on application forms.

Visible login/authentication gates pause before model planning or form actions. The app raises a persistent notification and makes the affected Browserbase session interactive. Resume rechecks the current page; an unresolved login pauses again. Application login also pauses the overall run, and its Resume agent button restarts the affected application. Password and verification-code values are never collected by the detector.

Discovery first calls JobSpy in an isolated 80-second process (Google Jobs, plus Naukri for India). Applicant contact details and documents are not passed to scrapers. Aggregator results resolve to company portals through public web searches before assessment. Direct searches also target Microsoft, Amazon, IBM, Accenture, Infosys, Cognizant, Oracle, Adobe and Dell, followed by ATS and general company sites. Source failures are recorded and discovery continues; they do not count as a successful scrape. JOBSPY_PROXIES may contain a private JSON array of configured proxy URLs; none are provided by default.

Discovery runs before Browserbase startup, so browser billing failures do not prevent collecting candidate company URLs. Browserbase HTTP 402 is surfaced explicitly and preserves discovery checkpoints for Resume after access is restored. Browser inspection, document preparation and submission remain blocked until a live session is available.
