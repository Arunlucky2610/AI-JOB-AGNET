import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Orbit — Your next move', description: 'A thoughtful job search, with you in control. Discover matches, tailor applications and watch your agent work.', icons: { icon: '/favicon.svg' } };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
