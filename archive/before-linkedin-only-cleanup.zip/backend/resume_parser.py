"""Conservative local extraction. Unrecognized facts stay blank for review."""
import re

def extract_profile(text):
    lines=[x.strip() for x in text.splitlines() if x.strip()]
    result={}
    email=re.search(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',text)
    phone=re.search(r'(?<!\w)(?:\+\d{1,3}[ .-]?)?(?:\(?\d{3}\)?[ .-]?)\d{3}[ .-]?\d{4}(?!\w)',text)
    if email:result['email']=email.group()
    if phone:result['phone']=phone.group().strip()
    if lines and re.fullmatch(r'[A-Za-zÀ-ž]+(?:[ .\'-]+[A-Za-zÀ-ž]+){1,4}',lines[0]) and not re.search(r'resume|curriculum|engineer|designer',lines[0],re.I):result['name']=lines[0]
    url=re.search(r'https?://(?:www\.)?(?:github\.com|linkedin\.com/in|[\w.-]+\.(?:dev|io|me))/[^\s,]*',text)
    if url:result['portfolio']=url.group()
    section=None;sections={'education':[],'work':[],'skills':[]}
    for line in lines:
        if re.match(r'^(education|academic background)\b',line,re.I):section='education'
        elif re.match(r'^(work experience|professional experience|employment|experience)\b',line,re.I):section='work'
        elif re.match(r'^(technical skills|skills|competencies)\b',line,re.I):section='skills'
        elif re.match(r'^(projects|certifications|awards|summary|profile)\s*:?$',line,re.I):section=None
        if section:sections[section].append(line)
    if sections['skills']:
        result['skills']=re.sub(r'^(technical skills|skills|competencies)\s*:?\s*','',', '.join(sections['skills']),flags=re.I)
    education=[]
    for line in sections['education']:
        degree=re.search(r'\b(Bachelor(?:[’\']s)?|Master(?:[’\']s)?|PhD|Ph\.D\.?|BS|BSc|B\.Sc|BA|BTech|B\.Tech|MSc|MS|MBA|Associate|Diploma)\b',line,re.I)
        if degree:
            year=re.search(r'\b(19\d{2}|20\d{2})\b',line)
            major=re.search(r'(?:in|of)\s+([A-Za-z &]+?)(?:,|\||\d|$)',line,re.I)
            school=re.search(r'(?:at|from|,|\|)\s*([^|,]*(?:University|College|Institute)[^|,]*)',line,re.I)
            d=degree.group().lower();kind='Bachelor’s degree' if d.startswith(('b','bachelor')) else 'Master’s degree' if d.startswith(('m','master')) else 'Doctorate' if d.startswith('ph') else 'Associate degree' if d.startswith('associate') else 'Diploma'
            education.append({'degree':kind,'school':school.group(1).strip() if school else '', 'year':year.group() if year else '', 'major':major.group(1).strip() if major else ''})
    if education:result['education']=education
    work=[]
    for i,line in enumerate(sections['work']):
        role=re.search(r'(?:Experience:\s*)?(.+?)\s+(?:at|@)\s+([^,|]+)',line,re.I)
        if role:
            dates=re.search(r'\b(20\d{2}|19\d{2})(?:-(\d{2}))?\s*[–—-]\s*(present|current|20\d{2}|19\d{2})(?:-(\d{2}))?',line,re.I)
            responsibilities=line[role.end():].strip(' ,.-') if not dates else line[dates.end():].strip(' .,-')
            rest=[]
            for next_line in sections['work'][i+1:]:
                if re.search(r'\s(?:at|@)\s',next_line):break
                rest.append(next_line)
            work.append({'title':role.group(1).strip(),'company':role.group(2).strip(),'start':f'{dates.group(1)}-{dates.group(2) or "01"}-01' if dates else '', 'end':f'{dates.group(3)}-{dates.group(4) or "01"}-01' if dates and dates.group(3).isdigit() else '', 'current':bool(dates and not dates.group(3).isdigit()),'responsibilities':'\n'.join([responsibilities,*rest]).strip()})
    if work:result['work_history']=work
    return {'fields':result,'notes':['Extracted locally without an LLM. Review every suggestion. Unrecognized information is left blank.','Year-only employment dates use January 1 as a placeholder; correct them before confirming.']}
