"""Integration checks on an isolated temporary SQLite database, no external calls."""
import os, tempfile, unittest
from pathlib import Path
from unittest.mock import patch

TEST_DIR=tempfile.TemporaryDirectory()
os.environ['DATABASE_URL']='sqlite:///'+str(Path(TEST_DIR.name)/'test.db').replace('\\','/')
os.environ['ALLOW_DEMO']='true'
from fastapi.testclient import TestClient
from .main import app
from .db import Session, Application, Job, now, engine
from .domain import evaluate, DEMO_PROFILE

def tearDownModule():
    engine.dispose()
    TEST_DIR.cleanup()

class ApiTests(unittest.TestCase):
    def setUp(self):
        self.client=TestClient(app,headers={'origin':'http://127.0.0.1:3000'})
        self.client.__enter__()
        self.assertEqual(self.client.post('/api/auth/demo',json={}).status_code,200)
    def tearDown(self):self.client.__exit__(None,None,None)
    def ready(self):return next(a for a in self.client.get('/api/applications').json() if a['status']=='prepared')
    def test_dashboard_is_computed(self):
        stats=self.client.get('/api/analytics').json()
        self.assertEqual(stats['discovered'],12)
        self.assertEqual(stats['counts']['submitted'],3)
        self.assertEqual(sum(stats['sources'].values()),12)
    def test_onboarding_starts_blank_without_login(self):
        fresh=TestClient(app,headers={'origin':'http://127.0.0.1:3000'})
        r=fresh.post('/api/workspace/init',json={})
        self.assertEqual(r.status_code,200)
        self.assertFalse(r.json()['demo'])
        self.assertFalse(r.json()['profile']['confirmed'])
        self.assertEqual(fresh.get('/api/jobs').json(),[])
    def test_resume_suggestions_are_not_guesses(self):
        text=b'Jordan Smith\njordan@example.com\n+1 212 555 1234\nEducation: BS in Computer Science, Example University, 2024\nExperience: Developer at Example Studio, 2024-present. Built web interfaces.\nSkills: Python, React'
        r=self.client.post('/api/profile/resume',files={'file':('resume.txt',text,'text/plain')})
        fields=r.json()['fields']
        self.assertEqual(fields['name'],'Jordan Smith')
        self.assertEqual(fields['email'],'jordan@example.com')
        self.assertEqual(fields['education'][0]['year'],'2024')
        self.assertEqual(fields['work_history'][0]['company'],'Example Studio')
        self.assertNotIn('eeo_gender',fields)
        self.assertNotIn('authorization',fields)
    def test_incomplete_profile_cannot_be_confirmed(self):
        from .domain import EMPTY_PROFILE
        self.assertEqual(self.client.put('/api/profile',json={**EMPTY_PROFILE,'confirmed':True}).status_code,422)
    def test_users_cannot_read_or_mutate_others(self):
        a=self.ready()
        other=TestClient(app,headers={'origin':'http://127.0.0.1:3000'})
        other.post('/api/auth/demo',json={})
        self.assertEqual(other.post('/api/applications/approve',json={'ids':[a['id']]}).status_code,404)
        self.assertEqual(other.get(f"/api/applications/{a['id']}/download").status_code,404)
    def test_approval_is_invalidated_on_edit(self):
        a=self.ready()
        self.assertEqual(self.client.post('/api/applications/approve',json={'ids':[a['id']]}).status_code,200)
        pack={**a['package'],'cover_letter':'Updated and reviewed facts.'}
        r=self.client.put(f"/api/applications/{a['id']}/package",json=pack)
        self.assertFalse(r.json()['approved'])
        self.assertEqual(r.json()['status'],'prepared')
        self.assertEqual(self.client.post(f"/api/applications/{a['id']}/action",json={'action':'start'}).status_code,409)
    def test_daily_limit_and_demo_transitions(self):
        self.client.put('/api/settings',json={'mode':'each','daily_limit':10,'threshold':70,'auto_enabled':False})
        a=self.ready();self.client.post('/api/applications/approve',json={'ids':[a['id']]})
        endpoint=f"/api/applications/{a['id']}/action"
        self.assertEqual(self.client.post(endpoint,json={'action':'start'}).json()['status'],'running')
        self.assertEqual(self.client.post(endpoint,json={'action':'takeover'}).json()['status'],'needs_input')
        self.assertEqual(self.client.post(endpoint,json={'action':'demo_advance'}).status_code,409)
        self.assertEqual(self.client.post(endpoint,json={'action':'resume'}).json()['status'],'running')
        for _ in range(5):r=self.client.post(endpoint,json={'action':'demo_advance'})
        self.assertEqual(r.json()['status'],'submitted')
        self.assertEqual(self.client.post(endpoint,json={'action':'start'}).status_code,409)
    def test_limit_blocks_new_start(self):
        self.client.put('/api/settings',json={'mode':'each','daily_limit':1,'threshold':70,'auto_enabled':False})
        with Session() as db:
            for a in db.query(Application).filter_by(status='submitted'):a.updated=now()
            db.commit()
        a=self.ready();self.client.post('/api/applications/approve',json={'ids':[a['id']]})
        self.assertEqual(self.client.post(f"/api/applications/{a['id']}/action",json={'action':'start'}).status_code,409)
    def test_missing_country_never_becomes_eligible(self):
        result=evaluate(DEMO_PROFILE,{'title':'Frontend Engineer','description':DEMO_PROFILE['skills'],'mode':'Remote','country':'','min_experience':2,'authorization_verified':True})
        self.assertFalse(result['eligible']);self.assertTrue(result['unknown'])
    def test_upload_and_download(self):
        r=self.client.post('/api/profile/resume',files={'file':('resume.txt',b'Real career history','text/plain')})
        self.assertEqual(r.json()['text'],'Real career history')
        self.assertEqual(self.client.post('/api/profile/resume',files={'file':('image.png',b'invalid','image/png')}).status_code,422)
        r=self.client.get(f"/api/applications/{self.ready()['id']}/download")
        self.assertEqual(r.status_code,200);self.assertTrue(r.content.startswith(b'PK'))
    def test_hostile_origin_is_rejected(self):
        r=self.client.post('/api/auth/demo',json={},headers={'origin':'https://evil.example'})
        self.assertEqual(r.status_code,403)
    def test_invalid_settings_rejected(self):
        self.assertEqual(self.client.put('/api/settings',json={'daily_limit':-1}).status_code,422)
    def test_submission_ambiguity_is_not_retryable(self):
        a=self.ready()
        with Session() as db:
            row=db.get(Application,a['id']);row.status='needs_verification';db.commit()
        self.assertEqual(self.client.post(f"/api/applications/{a['id']}/action",json={'action':'resume'}).status_code,409)

if __name__=='__main__':unittest.main()
