"""LinkedIn page helpers: search URLs, job discovery, and the Easy Apply dialog.

Nothing here reads or types credentials. Signing in, verification and CAPTCHAs are left to the person
in Live View (see human_gate.login_required).
"""
import re
from urllib.parse import quote_plus
from .domain import career_level

# Snapshot scope while an application is open: only the dialog's controls are offered to the model.
MODAL='.jobs-easy-apply-modal, .artdeco-modal, [role="dialog"]'
JOB_ID=re.compile(r'/jobs/view/(?:[^/?#]*-)?(\d{6,})')
SENT=re.compile(r'application sent|your application was sent|application submitted',re.I)

def job_url(job_id):
    return f'https://www.linkedin.com/jobs/view/{job_id}/'

def canonical(url):
    """One stable URL per vacancy, whatever tracking parameters or slug the link carried."""
    match=JOB_ID.search(url or '')
    return job_url(match.group(1)) if match else (url or '').split('?')[0].rstrip('/')

def experience_levels(profile):
    """LinkedIn's f_E codes: 1 internship, 2 entry, 3 associate, 4 mid-senior, 5 director."""
    try:years=float(profile.get('experience') or 0)
    except (TypeError,ValueError):years=0
    if career_level(profile) in ('intern','fresher'):return '1,2'
    if years<=3:return '2,3'
    if years<=6:return '3,4'
    return '4,5'

def search_urls(profile, roles=None, country_only=False):
    """Easy Apply job searches from the profile: one per role, newest first, past week."""
    roles=[r.strip() for r in (roles if roles is not None else profile.get('roles','')).split(',') if r.strip()][:5]
    city=(profile.get('locations') or '').split(',')[0].strip()
    country=(profile.get('country') or '').strip()
    place=country if country_only or not city else f'{city}, {country}' if country else city
    levels=experience_levels(profile).replace(',','%2C')
    location=f'&location={quote_plus(place)}' if place else ''
    return [f'https://www.linkedin.com/jobs/search/?keywords={quote_plus(role)}{location}&f_AL=true&f_E={levels}&f_TPR=r604800&sortBy=DD' for role in roles]

COLLECT_JS='''() => {
  const ids=new Set();
  document.querySelectorAll('[data-occludable-job-id],[data-job-id]').forEach(e=>{
    const v=e.getAttribute('data-occludable-job-id')||e.getAttribute('data-job-id');
    if(v&&/^\\d{6,}$/.test(v))ids.add(v);
  });
  document.querySelectorAll('a[href*="/jobs/view/"]').forEach(a=>{
    const m=a.href.match(/\\/jobs\\/view\\/(?:[^\\/?#]*-)?(\\d{6,})/);if(m)ids.add(m[1]);
  });
  return Array.from(ids);
}'''

# The results list is virtualised: scroll its container so further cards render.
SCROLL_JS='''() => {
  let el=document.querySelector('[data-occludable-job-id],[data-job-id]');
  while(el&&el.scrollHeight<=el.clientHeight+5)el=el.parentElement;
  (el||document.scrollingElement).scrollBy(0,1400);
}'''

async def collect_job_urls(page):
    """Vacancy links from the search results currently open in `page`."""
    await page.wait_for_timeout(2500)
    for _ in range(5):
        await page.evaluate(SCROLL_JS);await page.wait_for_timeout(800)
    return [job_url(i) for i in await page.evaluate(COLLECT_JS)]

STATE_JS='''() => {
  const shown=e=>e.getClientRects().length>0;
  const caption=e=>((e.innerText||'')+' '+(e.getAttribute('aria-label')||'')).trim();
  const controls=Array.from(document.querySelectorAll('button,a')).filter(shown).map(caption);
  const text=document.body.innerText;
  return {
    closed:/no longer accepting applications/i.test(text),
    easy:controls.some(t=>/^easy apply/i.test(t)),
    applied:/(^|\\n)\\s*applied\\b/i.test(text)||/see application status/i.test(text),
    external:controls.some(t=>/^apply\\b/i.test(t)&&!/easy apply/i.test(t)),
  };
}'''

async def apply_state(page):
    """'easy' | 'applied' | 'closed' | 'external' | 'unknown' for the job page open in `page`."""
    state=await page.evaluate(STATE_JS)
    if state['closed']:return 'closed'
    if state['easy']:return 'easy'
    if state['applied']:return 'applied'
    if state['external']:return 'external'
    return 'unknown'

# Playwright's selector engine sees into open shadow roots, where LinkedIn now renders the application dialog.
VISIBLE_MODAL=', '.join(part.strip()+':visible' for part in MODAL.split(','))

async def modal_open(page):
    return await page.locator(VISIBLE_MODAL).count()>0

async def open_easy_apply(page):
    """Click Easy Apply. Returns 'opened', or why not: 'closed' | 'applied' | 'not_easy'."""
    state=await apply_state(page)
    if state!='easy':return state if state in ('closed','applied') else 'not_easy'
    await page.locator('button:visible,a:visible').filter(has_text=re.compile(r'^\s*Easy Apply',re.I)).first.click(timeout=10000)
    try:
        await page.locator(VISIBLE_MODAL).first.wait_for(state='visible',timeout=12000)
    except Exception:
        return 'not_easy'
    return 'opened'

async def application_sent(page):
    return await page.get_by_text(SENT).count()>0

async def close_modal(page):
    """Best effort: dismiss the application dialog and discard the unfinished draft."""
    try:
        # Only the dialog's own close button: the page has other "Close" controls (menus, messaging).
        dismiss=page.locator(VISIBLE_MODAL).last.get_by_role('button',name=re.compile(r'dismiss|close',re.I)).first
        if await dismiss.count():
            await dismiss.click(timeout=5000)
            await page.locator(VISIBLE_MODAL).get_by_role('button',name=re.compile(r'^discard$',re.I)).first.click(timeout=5000)
    except Exception:
        pass
