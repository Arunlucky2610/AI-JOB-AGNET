"""Adapt pinned MIT Career Ops discovery and evaluation to Orbit's user state."""
import asyncio, json, os, re, shutil, subprocess
from fastapi import HTTPException
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT=Path(__file__).resolve().parent.parent
UPSTREAM=ROOT/'vendor'/'career-ops'
PROVIDERS={'greenhouse','ashby','lever','workday','smartrecruiters'}

def board_entry(url):
    p=urlparse(url);host=p.hostname or '';parts=p.path.strip('/').split('/')
    slug=parts[0]
    if host in ('boards.greenhouse.io','job-boards.greenhouse.io','job-boards.eu.greenhouse.io'):
        if slug=='embed':slug=parse_qs(p.query).get('for',[''])[0]
        if not re.fullmatch(r'[\w-]+',slug):return None
        return {'name':slug,'provider':'greenhouse','api':f'https://boards-api.greenhouse.io/v1/boards/{slug}/jobs','careers_url':url}
    if host in ('jobs.ashbyhq.com','jobs.lever.co','jobs.eu.lever.co','careers.smartrecruiters.com','jobs.smartrecruiters.com') and slug:
        return {'name':slug,'careers_url':f'https://{host}/{slug}'}
    if host.endswith('.myworkdayjobs.com') and len(parts)>=1:
        if re.fullmatch(r'[a-z]{2}-[A-Z]{2}',parts[0]):parts=parts[1:]
        if parts:return {'name':host.split('.')[0],'provider':'workday','careers_url':f'https://{host}/{parts[0]}','max_pages':20}
    return None

async def provider_jobs(urls, greenhouse_only=False):
    seeds=json.loads((ROOT/'backend'/'career_ops_portals.json').read_text(encoding='utf-8'))
    entries={}
    for entry in [*(board_entry(u) for u in urls),*seeds]:
        if not entry:continue
        if greenhouse_only and entry.get('provider')!='greenhouse' and 'boards-api.greenhouse.io/' not in entry.get('api',''):continue
        key=entry.get('api') or entry.get('careers_url')
        entries.setdefault(key,entry)
    node=os.getenv('NODE_BINARY') or shutil.which('node')
    if not node:raise RuntimeError('Node.js is required for Career Ops providers')
    def run():
        r=subprocess.run([node,str(ROOT/'backend'/'career_ops_bridge.mjs')],input=json.dumps({'entries':list(entries.values())[:35]}),capture_output=True,text=True,encoding='utf-8',timeout=240,cwd=ROOT)
        if r.returncode:raise RuntimeError('Career Ops provider bridge failed: '+r.stderr[-400:])
        return json.loads(r.stdout)
    return await asyncio.to_thread(run)

def prioritize(jobs,profile):
    """Cheap role/geo ordering; never infer remote eligibility or fresher suitability."""
    ai=any(re.search(r'\b(ai|ml|machine learning|generative)\b',r,re.I) for r in profile.get('roles','').split(','))
    role_words=[r.strip().lower() for r in profile.get('roles','').split(',') if r.strip()]
    country=profile.get('country','').lower()
    cities=r'hyderabad|bengaluru|bangalore|mumbai|pune|chennai|gurugram|gurgaon|noida|delhi|india'
    selected=[]
    for job in jobs:
        title=job.get('title','');loc=job.get('location','')
        role=bool(re.search(r'\b(ai|ml|machine learning|artificial intelligence|generative)\b',title,re.I)) if ai else any(r in title.lower() for r in role_words)
        if not role:continue
        # Keep ambiguous/remote locations for assessment, but place explicit target geography first.
        geo=bool(country and country in loc.lower()) or (country=='india' and bool(re.search(cities,loc,re.I)))
        junior=bool(re.search(r'graduate|fresher|junior|entry|intern|associate',title,re.I))
        senior=bool(re.search(r'\b(senior|sr|lead|staff|principal|architect|manager)\b',title,re.I))
        selected.append((int(geo)*8+int(junior)*4-int(senior)*6,job))
    return [j for _,j in sorted(selected,key=lambda item:item[0],reverse=True)]

def evaluation_instructions():
    """Use upstream evidence tiers and requirement importance, adapted to freshers."""
    source=(UPSTREAM/'modes'/'oferta.md').read_text(encoding='utf-8')
    evidence=source[source.index('### Evidence tiers'):source.index('### Gaps')][:1800]
    return (' REQUIRED JSON ROOT PROPERTIES, in addition to the requested job assessment fields: "evaluation" (OBJECT) and "global_score" (number). The exact shape is {"evaluation":{"A":"role summary","B":[{"requirement":"requirement","importance":"high","tier":"stated","jd_evidence":"exact JD excerpt","profile_evidence":"exact profile excerpt or empty","match":"strong|partial|missing|unknown"}],"C":"seniority fit","D":"advertised pay only","E":"tailoring plan","F":"interview preparation","G":"posting risks","H":"screening questions needing user input"},"global_score":3.0}. NEVER omit evaluation. A,C,D,E,F,G,H are strings; B is an array, never a Markdown table. '
            'Each B row has requirement, importance (critical/high/meaningful/low), tier (stated/structural/inferred), jd_evidence (exact JD quote), profile_evidence (exact confirmed resume/profile quote, or empty), profile_evidence_ids (array of supplied confirmed_evidence IDs), match (strong/partial/missing/unknown). Cite supporting confirmed_evidence IDs rather than paraphrasing quotes. Personal project evidence supports hands-on skills, not professional years. Prefer 8 rows, max 12 except retain every critical/high requirement. Each quote <=180 characters, requirement <=120 characters. Each A,C,D,E,F,G,H block <=35 words. Inferred requirements cannot be critical/high. Never fabricate evidence. Never apply senior-founder defaults to a graduate. Also return global_score (1-5, holistic skill/role fit; not an employer ATS result). No researched salary or external assumptions. Upstream reference methodology follows; its prose/table formatting instructions do not override the requested JSON schema: '+evidence+' Return only the compact JSON object, no Markdown report or extra keys. Entire evaluation <=1200 words.')

def evidence_catalog(profile):
    lines=[{'source':'resume','text':line.strip()} for line in profile.get('resume_text','').splitlines() if line.strip()]
    for field in ['skills','experience','education','work_history','country','authorization','sponsorship','relocation','employment_type','portfolio']:
        value=profile.get(field)
        if value is not None and value!='' and value!=[]:lines.append({'source':field,'text':value if isinstance(value,str) else json.dumps(value,ensure_ascii=False)})
    return [{'id':f'e{i+1}','source':line['source'],'text':line['text'][:400]} for i,line in enumerate(lines[:160])]

async def verify_posting(url, snapshot=None):
    node=os.getenv('NODE_BINARY') or shutil.which('node')
    def run():
        r=subprocess.run([node,str(ROOT/'backend'/'career_ops_verify.mjs')],input=json.dumps({'url':url,'apiOnly':snapshot is None,'snapshot':snapshot}),capture_output=True,text=True,encoding='utf-8',timeout=35,cwd=ROOT)
        if r.returncode:raise RuntimeError('Career Ops verification adapter failed')
        return json.loads(r.stdout)
    return await asyncio.to_thread(run)

def validated_evaluation(result, profile, job_text):
    raw=result.get('evaluation') or result.get('structured_evaluation') or result.get('career_ops_evaluation')
    if not isinstance(raw,dict) and all(k in result for k in 'ABCDEFGH'):raw={k:result[k] for k in 'ABCDEFGH'}
    if not isinstance(raw,dict):raise HTTPException(502,'The model omitted the required Career Ops report. Retry assessment; no fit result was saved.')
    rows=raw.get('B')
    if not isinstance(rows,list):raise HTTPException(502,'The model returned an invalid Career Ops requirements table. Retry assessment; no fit result was saved.')
    evidence=json.dumps(profile,ensure_ascii=False).casefold()+' '+profile.get('resume_text','').casefold()
    def norm(value):return re.sub(r'\s+',' ',value.casefold()).strip()
    evidence=norm(evidence);jd=norm(job_text);clean=[]
    catalog={entry['id']:entry for entry in evidence_catalog(profile)}
    for row in rows[:30]:
        if not isinstance(row,dict):continue
        r={k:str(row.get(k) or '')[:1800] for k in ['requirement','importance','tier','jd_evidence','profile_evidence','match']}
        refs=row.get('profile_evidence_ids')
        cited=[catalog[id]['text'] for id in refs[:3] if isinstance(id,str) and id in catalog] if isinstance(refs,list) else []
        if cited:r['profile_evidence']=' | '.join(cited)
        if r['tier'] not in ['stated','structural','inferred']:r['tier']='inferred'
        if r['importance'] not in ['critical','high','meaningful','low']:r['importance']='meaningful'
        if r['tier']=='inferred' and r['importance'] in ['critical','high']:r['importance']='meaningful'
        if r['jd_evidence'] and norm(r['jd_evidence']) not in jd:r.update(tier='inferred',importance='meaningful',jd_evidence='')
        if r['match'] not in ['strong','partial','missing','unknown']:r['match']='unknown'
        if r['profile_evidence'] and not cited and norm(r['profile_evidence']) not in evidence:r.update(profile_evidence='',match='unknown')
        if r['match'] in ['strong','partial'] and not r['profile_evidence']:r['match']='unknown'
        clean.append(r)
    clean.sort(key=lambda r:({'critical':0,'high':1,'meaningful':2,'low':3}[r['importance']],r['match']=='strong'))
    return {**{k:str(raw.get(k) or 'Not stated / not assessed')[:2000] for k in 'ACDEFGH'},'B':clean,'global_score':max(1,min(5,float(result.get('global_score',3)))),'source':'Career Ops A-H adapted for Orbit'}

def enforce_evidence_constraints(match):
    """A high similarity score cannot override an evidenced mandatory gap."""
    for row in match.get('evaluation',{}).get('B',[]):
        if row['importance']!='critical' or row['tier']!='stated' or not row['jd_evidence']:continue
        if row['match']=='missing':match['blockers'].append('Mandatory requirement not evidenced in profile: '+row['requirement'])
        elif row['match']=='unknown':match['unknown'].append('Mandatory requirement needs confirmation: '+row['requirement'])
    match['blockers']=list(dict.fromkeys(match['blockers']));match['unknown']=list(dict.fromkeys(match['unknown']))
    if match['blockers'] or match['unknown']:match.update(eligible=False,matched=False)
    return match
