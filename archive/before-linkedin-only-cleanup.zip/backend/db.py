import os
from datetime import datetime, timezone
from pathlib import Path
from sqlalchemy import create_engine, Column, String, Text, DateTime, JSON, ForeignKey, UniqueConstraint
from sqlalchemy.orm import declarative_base, sessionmaker
from dotenv import load_dotenv

load_dotenv()
Path('data').mkdir(exist_ok=True)
URL = os.getenv('DATABASE_URL', 'sqlite:///./data/orbit.db')
engine = create_engine(URL, connect_args={'check_same_thread': False} if URL.startswith('sqlite') else {}, pool_pre_ping=True)
Session = sessionmaker(bind=engine, expire_on_commit=False)
Base = declarative_base()
def now(): return datetime.now(timezone.utc)

class User(Base):
    __tablename__ = 'users'
    id = Column(String, primary_key=True)
    email = Column(String, unique=True, nullable=False)
    password = Column(Text, nullable=False)
    profile = Column(JSON, default=dict)
    settings = Column(JSON, default=dict)
    demo = Column(String, default='false')

class Login(Base):
    __tablename__ = 'sessions'
    token = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey('users.id'), nullable=False)
    expires = Column(DateTime(timezone=True), nullable=False)

class Job(Base):
    __tablename__ = 'jobs'
    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey('users.id'), nullable=False, index=True)
    canonical = Column(String, nullable=False)
    payload = Column(JSON, nullable=False)
    created = Column(DateTime(timezone=True), default=now)
    __table_args__ = (UniqueConstraint('user_id', 'canonical'),)

class Application(Base):
    __tablename__ = 'applications'
    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey('users.id'), nullable=False, index=True)
    job_id = Column(String, ForeignKey('jobs.id'), nullable=False)
    status = Column(String, default='prepared')
    package = Column(JSON, default=dict)
    approved_hash = Column(String, nullable=True)
    events = Column(JSON, default=list)
    browser = Column(JSON, default=dict)
    created = Column(DateTime(timezone=True), default=now)
    updated = Column(DateTime(timezone=True), default=now)
    __table_args__ = (UniqueConstraint('user_id', 'job_id'),)

class AgentRun(Base):
    __tablename__ = 'agent_runs'
    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey('users.id'), nullable=False, index=True)
    status = Column(String, default='running')
    phase = Column(String, default='searching')
    events = Column(JSON, default=list)
    browser = Column(JSON, default=dict)
    state = Column(JSON, default=dict)
    created = Column(DateTime(timezone=True), default=now)
    updated = Column(DateTime(timezone=True), default=now)

class BrowserContext(Base):
    """A user's saved Browserbase browser profile: keeps LinkedIn/Indeed logins across sessions."""
    __tablename__ = 'browser_contexts'
    user_id = Column(String, ForeignKey('users.id'), primary_key=True)
    context_id = Column(String, nullable=False)
    created = Column(DateTime(timezone=True), default=now)

def init():
    Base.metadata.create_all(engine)
    with Session() as db:
        for a in db.query(Application).filter(Application.status.in_(['running','submitting'])):
            a.status = 'needs_verification' if a.status == 'submitting' else 'needs_input'
            a.events = [*a.events, {'time': now().isoformat(), 'text': 'Worker restarted. Review the application before continuing.'}]
        db.commit()

        for run in db.query(AgentRun).filter_by(status='running'):
            run.status='paused'
            run.events=[*run.events,{'time':now().isoformat(),'text':'Server restarted. Resume the agent to continue.'}]
        db.commit()
