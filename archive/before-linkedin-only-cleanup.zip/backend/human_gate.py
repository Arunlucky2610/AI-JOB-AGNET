"""Detect visible authentication gates without reading credential values."""
LOGIN_PROBE = r"""() => {
    const visible=e => !!(e.getClientRects().length && getComputedStyle(e).visibility!=='hidden' && getComputedStyle(e).display!=='none');
    const inputs=Array.from(document.querySelectorAll('input')).filter(visible);
    if(inputs.some(e=>e.type==='password')) return true;
    // LinkedIn's own sign-in walls and security checks need the person, not the agent.
    if(/(^|\.)linkedin\.com$/.test(location.hostname) && /^\/(checkpoint|authwall|uas\/|login|signup)/.test(location.pathname)) return true;
    if(inputs.some(e=>e.autocomplete==='one-time-code')) return true;
    const login=/\b(sign[\s-]*in|log[\s-]*in|login|create an account|verify your email)\b/i;
    const dialogs=Array.from(document.querySelectorAll('[role="dialog"],dialog[open]')).filter(visible);
    if(dialogs.some(e=>login.test(e.querySelector('h1,h2,h3,[role="heading"]')?.innerText||'') && e.querySelector('input,button'))) return true;
    const text=document.body.innerText;
    const authPath=/(?:^|\/)(?:login\d*|signin|sign-in|log-in|auth|authenticate|register)(?:\/|$)/i.test(location.pathname);
    const emailOnly=inputs.some(e=>e.type==='email'||/email|username/i.test((e.name||'')+' '+(e.id||'')+' '+(e.getAttribute('aria-label')||''))) && !inputs.some(e=>/first.?name|last.?name|full.?name|resume|phone/i.test((e.name||'')+' '+(e.id||'')+' '+(e.getAttribute('aria-label')||'')));
    const loginButton=Array.from(document.querySelectorAll('button,input[type="submit"]')).filter(visible).some(e=>/^(sign[\s-]*in|log[\s-]*in|login|sign[\s-]*in with (google|microsoft)|send me a sign[\s-]*in link|continue with (google|microsoft|email))$/i.test((e.innerText||e.value||'').trim()));
    return (authPath && login.test(text)) || (emailOnly && loginButton);
}"""

async def login_required(page):
    return await page.evaluate(LOGIN_PROBE)
